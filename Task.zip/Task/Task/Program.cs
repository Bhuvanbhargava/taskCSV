﻿using System;
using System.IO;
using System.Linq;

namespace CSVFileHandler
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*****************************************************");
            Console.WriteLine("This project using the embeded data.csv file in case no file or location provided");
            Console.WriteLine("*****************************************************");
            FILEPATH:
            Console.WriteLine("Please specify file location or press enter to use default embedded file");
            
            var filePath=Console.ReadLine();
            if (string.IsNullOrWhiteSpace(filePath))
            {
                filePath = @"..\..\Files";
            }
            DirectoryInfo dirinfo = new DirectoryInfo(filePath);
            if (!dirinfo.Exists)
            {
                Console.WriteLine("Directory {0} does not exist", filePath);
                Console.WriteLine();
                goto FILEPATH;
            }
            FileInfo[] files = dirinfo.GetFiles("*.csv");
            if (files.Length == 0)
            {
                Console.WriteLine("no csv file fount at {0}", filePath);
                goto FILEPATH;
            }
            FILESELECTION:
            int counter = 1;
            Console.WriteLine("Please enter a number in front of the corrospoding file to select");
            foreach (var file in files)
            {
                Console.WriteLine("{0} - {1}", counter++, file.Name);
                
            }
            --counter;//decrease the additonl counter to maintain the index;

            int selectedFileId;
            int.TryParse(Console.ReadLine(), out selectedFileId);
            if (selectedFileId > counter || selectedFileId <= 0)
            {
                goto FILESELECTION;
            }
            var selectedFile = files[--selectedFileId];
            Console.WriteLine("Ok! processing ({0}) file." ,selectedFile);
            var result =StartFileProcessing(selectedFile);
            CreateFile(filePath, result);
            Console.ReadLine();
        }

        private static void CreateFile(string filePath, ResultViewModel result)
        {
            var frequencyFile = string.Format("{0}\\OrderNamesbyFreqAndAlph.txt", filePath);
            var addressFile = string.Format("{0}\\OrderAddressAlph.txt", filePath);
            File.WriteAllLines(frequencyFile, result.FrequencyResult.Select(a=>a.Item));
            File.WriteAllLines(addressFile, result.AddressResult.Select(a => a.Address));
            Console.WriteLine();
            Console.WriteLine("********Files are saved at ({0}).**********", filePath);
        }

        public static ResultViewModel StartFileProcessing(FileInfo file)
        {            
            using (FileStream fileStream = File.OpenRead(file.FullName))
            {             
                MemoryStream memoryStream = new MemoryStream();
                memoryStream.SetLength(fileStream.Length);               
                fileStream.Read(memoryStream.GetBuffer(), 0, (int)fileStream.Length);
                FileHandler fh = new FileHandler();
                var result=fh.ProcessFile(memoryStream);

                //Print the FrequencyResult
                Console.WriteLine();
                Console.WriteLine("Order name and lastname by frequency than alphabet");
                foreach (var item in result.FrequencyResult)
                {
                    Console.WriteLine("{0} - {1}", item.Item, item.Frequency);
                }
                ;
                // Print the AddressResult
                Console.WriteLine();
                Console.WriteLine("Order address by alphabet");
                foreach (var item in result.AddressResult)
                {
                    Console.WriteLine("{0} ", item.Address);
                }
                return result;
            }            
        }
    }
}
