﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace CSVFileHandler
{
    public  class FileHandler : IFileHandler
    {
        public ResultViewModel ProcessFile(MemoryStream stream)
        {
            if (stream.Length == 0)
            {
                throw new ArgumentException("No data found to process");
            }
            var listItem = new List<string>();
            var addressItem = new List<AddressModel>();
            StreamReader sr = new StreamReader(stream);
            sr.ReadLine();//skip the first line as header
            while (!sr.EndOfStream)
            {
                var linetext = sr.ReadLine();
                if (!string.IsNullOrWhiteSpace(linetext))
                {
                    var arr = linetext.Split(',');
                    listItem.Add(string.Format(arr[0]).Trim().ToLower());
                    listItem.Add(string.Format(arr[1]).Trim().ToLower());
                    addressItem.Add(new AddressModel
                    { 
                       Address= string.Format(arr[2].Trim().ToLower())
                    });
                }
            }
            var result1 = FrequencyBasedOrder(listItem);
            var result2 = AddressOrderByStreetName(addressItem);
            return new ResultViewModel()
            {
                FrequencyResult = result1,
                AddressResult = result2
            };
                     
        }

        private List<AddressModel> AddressOrderByStreetName(List<AddressModel> addressItem)
        {
            addressItem.ForEach(a =>
            {
                int index = 0;
                char[] arr = a.Address.ToCharArray();
                for (int i = 0; i < arr.Length; i++)
                {
                    if (Char.IsLetter(arr[i]))
                    {
                        index = i;
                        break;
                    }
                }
                a.SortString = a.Address.Substring(index);
            });

            return addressItem.OrderBy(a => a.SortString).ToList();
        }

       
        private List<FrequencyModel> FrequencyBasedOrder(List<string> listItems)
        {

            List<FrequencyModel> model = new List<FrequencyModel>();
            foreach (var listItem in listItems)
            {
                if (model.Any(a=>a.Item== listItem))
                {
                   var itemfrq = model.FirstOrDefault(a => a.Item == listItem).Frequency;
                    model.FirstOrDefault(a => a.Item == listItem).Frequency = ++itemfrq;
                }
                else
                {                    
                    model.Add(new FrequencyModel { Item = listItem, Frequency = 1 });
                }
            }

            return model.OrderByDescending(a=>a.Frequency).ThenBy(a=>a.Item).ToList();
            
        }
    
    }
}
