﻿namespace CSVFileHandler
{
    public class FrequencyModel
    {
        public int Frequency { get; set; }
        public string Item { get; set; }
    }
}
