﻿using System.IO;

namespace CSVFileHandler
{
    public interface IFileHandler
    {
        ResultViewModel ProcessFile(MemoryStream stream);
    }
}